#include "../mist_policy.h"
#include <cassert>
#include <cstdio>

int main() {
  const struct { float humidity; unsigned duty, ms; } cases[] = {
    {NAN,0,0}, {-1,0,0}, {0,100,30000}, {29.9f,100,30000}, {30,50,20000},
    {34.9f,50,20000}, {35,25,10000}, {39.9f,25,10000}, {40,0,0}, {60,0,0}, {65,0,0}
  };
  for (const auto &row : cases) {
    const auto profile = mistProfile(row.humidity);
    assert(profile.percent == row.duty && profile.durationMs == row.ms);
    MistCycle cycle;
    cycle.updateHumidity(row.humidity, 0);
    assert(cycle.refresh(0) == (row.duty > 0));
    assert(cycle.percent() == row.duty);
    if (!row.duty) continue;
    for (unsigned time = 2500; time < row.ms; time += 2500) {
      cycle.updateHumidity(row.humidity, time);
      assert(!cycle.refresh(time));
    }
    assert(!cycle.refresh(row.ms - 1));
    cycle.updateHumidity(row.humidity, row.ms);
    assert(cycle.refresh(row.ms) && cycle.percent() == 0);
    assert(!cycle.refresh(row.ms + 4999));
    cycle.updateHumidity(row.humidity, row.ms + 5000);
    assert(cycle.refresh(row.ms + 5000) && cycle.percent() == row.duty);
    cycle.updateHumidity(40, row.ms + 5100);
    assert(cycle.refresh(row.ms + 5100) && cycle.percent() == 0);
  }
  MistCycle stale;
  stale.updateHumidity(25, 0);
  assert(stale.refresh(0) && stale.percent() == 100);
  assert(stale.refresh(6000) && stale.percent() == 0);
  std::puts("PASS: 11 humidity cases, pulse timing, rest, early stop and stale-sample cutoff.");
}
