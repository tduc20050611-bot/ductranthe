const assert = require('node:assert/strict');
const { EventEmitter } = require('node:events');
const { readFileSync } = require('node:fs');
const { join } = require('node:path');
const vm = require('node:vm');

const elements = new Map();
const handlers = new Map();
const canvasContext = new Proxy({}, { get: (_, key) => key === 'fillText' ? (_, x, y) => {
  assert(Number.isFinite(x) && Number.isFinite(y));
} : () => {} });
const document = { getElementById(id) {
  if (!elements.has(id)) elements.set(id, {
    clientWidth: 420, clientHeight: 154,
    getContext: () => canvasContext, setAttribute() {},
    addEventListener: (name, callback) => handlers.set(id + ':' + name, callback)
  });
  return elements.get(id);
} };
const broker = new EventEmitter();
broker.connected = true;
broker.subscribe = (topics, done) => {
  assert.equal(topics.length, 3);
  done(null);
};
const published = [];
broker.publish = (topic, payload, options, done) => {
  published.push({topic, payload, options});
  done(null);
};
let tick;
const window = {addEventListener() {}, devicePixelRatio: 1, mqtt: {connect() { return broker; }}};
vm.runInNewContext(readFileSync(join(__dirname, '../dashboard.js'), 'utf8'), {
  document, window, setInterval: callback => { tick = callback; }
});
const root = elements.get('namespace').textContent;
const emit = (name, value) => broker.emit('message', root + '/' + name, JSON.stringify(value));
broker.emit('connect');
assert.match(elements.get('connection').textContent, /đã kết nối/);
emit('telemetry', {temperature:25, humidity:37.5, valid:true});
assert.equal(elements.get('temperature').textContent, '25.0');
assert.equal(elements.get('humidity').textContent, '37.5');
emit('state', {pump:0, fan:0, mist:25});
assert.equal(elements.get('mist').textContent, '25% PWM');

const state = {pump:0, fan:0, mist:25};
for (const key of ['pump', 'fan']) {
  for (const expected of [1, 0]) {
    assert.equal(elements.get(key).disabled, false);
    handlers.get(key + ':click')();
    assert.equal(elements.get(key).disabled, true);
    assert.equal(published.at(-1).topic, root + '/cmd/' + key);
    assert.equal(published.at(-1).payload, String(expected));
    assert.equal(published.at(-1).options.retain, false);
    state[key] = expected;
    emit('state', state);
    assert.equal(elements.get(key).disabled, false);
    assert.match(elements.get('commandStatus').textContent, /phản hồi/);
  }
}
emit('telemetry', {temperature:null, humidity:null, valid:false});
assert.equal(elements.get('temperature').textContent, '—');
broker.connected = false;
broker.emit('close');
tick();
assert.equal(elements.get('pump').disabled, true);
assert.equal(elements.get('fan').disabled, true);
console.log('PASS: MQTT dashboard with simulated broker events; data, charts, four manual commands, acknowledgements and disconnect.');
